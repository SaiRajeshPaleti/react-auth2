// ##########################################
// NOTE: This file is not part of the package.
// It's only function is to help development in testing and debugging.
// If you want to run the project locally you will need to update the authConfig object with your own auth provider
// ##########################################

import React, { useContext } from 'react'
import { createRoot } from 'react-dom/client'
import { AuthContext, AuthProvider } from "react-oauth2-code-pkce"

// Get auth provider info from "https://keycloak.ofstad.xyz/realms/master/.well-known/openid-configuration"
const authConfig = {
  clientId: 'account',
  authorizationEndpoint: 'https://keycloak.ofstad.xyz/realms/master/protocol/openid-connect/auth',
  tokenEndpoint: 'https://keycloak.ofstad.xyz/realms/master/protocol/openid-connect/token',
  logoutEndpoint: 'https://keycloak.ofstad.xyz/realms/master/protocol/openid-connect/logout',
  redirectUri: 'http://localhost:3000/',
  onRefreshTokenExpire: (event) =>
    window.confirm('Tokens have expired. Refresh page to continue using the site?') && event.login(),
  decodeToken: true,
  scope: 'profile openid',
  // state: 'testState',
  clearURL: true,
  autoLogin: false,
  storage: 'local',
  refreshWithScope: false,
}

function LoginInfo() {
  const { tokenData, token, idTokenData, login, logOut, error, loginInProgress, idToken } = useContext(AuthContext)

  if (loginInProgress) return null
  return (
    <>
      {error && <div style={{ color: 'red' }}>An error occurred during authentication: {error}</div>}
      <>
        <button onClick={login}>Login</button>
        <button onClick={() => login('customLoginState')}>Login w/state</button>
        <button onClick={() => login('customLoginState', { scope: 'profile', something: 123 })}>
          Login w/extra params
        </button>
      </>
      {token ? (
        <>
          <button onClick={() => logOut('rememberThis', idTokenData.session_state)}>Logout</button>
          <span style={{ margin: '0 10px' }}>
            Access token will expire at:{' '}
            {new Date(localStorage.getItem('ROCP_tokenExpire') * 1000).toLocaleTimeString()}
          </span>
          <div style={{ display: 'flex', flexWrap: 'wrap' }}>
            <div>
              <h4>Access Token (JWT)</h4>
              <pre
                style={{
                  width: '400px',
                  margin: '10px',
                  padding: '5px',
                  border: 'black 2px solid',
                  wordBreak: 'break-all',
                  whiteSpace: 'break-spaces',
                }}
              >
                {token}
              </pre>
            </div>
            {authConfig.decodeToken && (
              <>
                <div>
                  <h4>Login Information from Access Token</h4>
                  <pre
                    style={{
                      width: '400px',
                      margin: '10px',
                      padding: '5px',
                      border: 'black 2px solid',
                      wordBreak: 'break-all',
                      whiteSpace: 'break-spaces',
                    }}
                  >
                    {JSON.stringify(tokenData, null, 2)}
                  </pre>
                </div>
                <div>
                  <h4>Login Information from ID Token</h4>
                  <pre
                    style={{
                      width: '400px',
                      margin: '10px',
                      padding: '5px',
                      border: 'black 2px solid',
                      wordBreak: 'break-all',
                      whiteSpace: 'break-spaces',
                    }}
                  >
                    {JSON.stringify(idTokenData, null, 2)}
                  </pre>
                </div>
              </>
            )}
          </div>
        </>
      ) : (
        <div style={{ backgroundColor: 'red' }}>You are not logged in</div>
      )}
    </>
  )
}

const container = document.getElementById('root')
const root = createRoot(container)

root.render(
  <React.StrictMode>
   
    <AuthProvider authConfig={authConfig}>
      <LoginInfo />
    </AuthProvider>
  </React.StrictMode>
)